import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';  // Reactive form services
import { EmployeeService } from 'src/app/services/employee.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr'; // Alert message using NGX toastr


@Component({
  selector: 'app-create-employees',
  templateUrl: './create-employees.component.html',
  styleUrls: ['./create-employees.component.css']
})
export class CreateEmployeesComponent implements OnInit {
  createEmployee: FormGroup;
  submitted = false;
  loading = false;
  id: string | null;
  title = 'Create Employee';


  constructor(private fb: FormBuilder,
    private _employeeService: EmployeeService,
    private router: Router,
    private toastr: ToastrService,
    private actRoute: ActivatedRoute) {
      this.createEmployee = this.fb.group({
      firstname: ['',Validators.required],
      position: ['',Validators.required],
      salary: ['',Validators.required],
      contact: ['',Validators.required],
      email: ['',Validators.required]
    })
    this.id = this.actRoute.snapshot.paramMap.get('id');
    console.log(this.id);
  }
  ngOnInit(): void {
    this.isEdit();
  }

  addEditEmployee() {
    this.submitted = true;

    if (this.createEmployee.invalid) {
      return;
    }

    if (this.id === null) {
      this.addEmployee();
    }else {
      this.editEmployee(this.id);
    }
  }


  addEmployee() {
    this.title = 'Create Employee';
    const employee: any = {
      lastname: this.createEmployee.value.lastname,
      firstname: this.createEmployee.value.firstname,
      position: this.createEmployee.value.position,
      salary: this.createEmployee.value.salary,
      contact: this.createEmployee.value.contact,
      email: this.createEmployee.value.email,
      creationDate: new Date(),
      dateUpdate: new Date()
    }
    this.loading = true;
    this._employeeService.addEmployee(employee).then(() =>{
      this.toastr.success('Employee record was successfully created','Created successfully!', {
        positionClass: 'toast-bottom-right'
      })
      this.loading = false;
      this.router.navigate(['/list-employees'])
    }).catch(error => {
      console.log(error);
      this.loading = false;
    })
  }

  editEmployee(id: string){
    const employee: any = {
      lastname: this.createEmployee.value.lastname,
      firstname: this.createEmployee.value.firstname,
      position: this.createEmployee.value.position,
      salary: this.createEmployee.value.salary,
      contact: this.createEmployee.value.contact,
      email: this.createEmployee.value.email,
      dateUpdate: new Date()
    }
    this.loading = true;
    this._employeeService.updateEmployee(id, employee).then(() => {
      this.loading = false;
      this.toastr.info('Employee record was successfully updated', 'Updated successfully!', {
        positionClass: 'toast-bottom-right'
      })
      this.router.navigate(['/list-employees'])
    })
  }

  isEdit() {
    if(this.id !== null) {
      this.loading = true;
      this._employeeService.getEmployee(this.id).subscribe(data  => {
        this.title = 'Edit Employee';
        this.loading = false;
        this.createEmployee.setValue({
          lastname: data.payload.data()['lastname'],
          firstname: data.payload.data()['firstname'],
          position: data.payload.data()['position'],
          salary: data.payload.data()['salary'],
          contact: data.payload.data()['contact'],
          email: data.payload.data()['email']
        })

      })
    }
  }

}
