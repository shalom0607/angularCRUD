export const environment = {
  firebase: {
    apiKey: "AIzaSyCezOKDgPG1iB5pDR3qLOP-3l707dQI7fE",
    authDomain: "angularcrud-34c77.firebaseapp.com",
    projectId: "angularcrud-34c77",
    storageBucket: "angularcrud-34c77.appspot.com",
    messagingSenderId: "930304171546",
    appId: "1:930304171546:web:fcb188f96ba030c5c27ba3"
  },
  production: true
};
