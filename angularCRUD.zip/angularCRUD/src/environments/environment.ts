// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    apiKey: "AIzaSyCezOKDgPG1iB5pDR3qLOP-3l707dQI7fE",
    authDomain: "angularcrud-34c77.firebaseapp.com",
    projectId: "angularcrud-34c77",
    storageBucket: "angularcrud-34c77.appspot.com",
    messagingSenderId: "930304171546",
    appId: "1:930304171546:web:fcb188f96ba030c5c27ba3"
  },
  production: false
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
